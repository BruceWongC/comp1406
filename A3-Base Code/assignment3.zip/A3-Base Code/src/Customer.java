import java.util.*;

public class Customer implements java.io.Serializable{
    private String name;
    private LinkedHashMap<Product, Integer> history;//product -> amount. Also higher computation time, but in inserted order
    public Customer(String n){
        name = n;
        history = new LinkedHashMap<>();
    }
    public boolean addHistory(Product p, int amount){
        history.put(p,amount);
        return true;
    }
    public HashMap<Product, Integer> getHistory(){
        return history;
    }
    public void printPurchaseHistory(){ //get the toString and the quantity of the item
        for (Product p : history.keySet()) {
            System.out.println(history.get(p) + " x " + p.toString());
        }
    }
    public String getName(){
        return name;
    }
    public int totalSpent(){
        int total = 0;
        for (Product p : this.getHistory().keySet()){//history also needs testing
            total += p.getPrice() * this.getHistory().get(p);

        }

        return total;
    }
    public String toString() {
        return name + " who has spent " + totalSpent() ;
    }

}
