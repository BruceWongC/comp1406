//Class representing an electronic store
//Has an array of products that represent the items the store can sell
import java.io.*;
import java.util.*;

public class ElectronicStore{
  private String name;
  private List<Product> stock; //Array to hold all products
  private List<Customer> cust; //Array to hold all customers
  public ElectronicStore(String initName){
    name = initName;
    stock = new ArrayList<>();
    cust = new ArrayList<>();
  }
  public boolean registerCustomer(Customer c){
    for (Customer C : cust) {
      if (C.getName().equals(c.getName())) {//if names are equal, not unique
        return false;
      }
    }

    return cust.add(c);
  }
  public List<Customer> getCustomers(){
    return cust;
  }
  public List<Product> searchProducts(String x){
    List<Product> list = new ArrayList<>();
    for (Product p : stock){
      if (p.toString().toLowerCase().contains(x.toLowerCase())){//puts everything lowercase so contains works as intended
        list.add(p);
      }
    }
    return list;
  }
  public List<Product> searchProducts(String x, double minPrice, double maxPrice){
    List<Product> list = searchProducts(x);
    List<Product> newlist = new ArrayList<>();

    if (maxPrice < 0 && minPrice >= 0) {//at beginning so if min > max, but is negative
      for (Product p : list) {
        if (p.getPrice() >= minPrice){
          newlist.add(p);
        }
      }
      return newlist;
    }

    else if (minPrice > maxPrice || minPrice < 0 && maxPrice < 0){//if min > max, but is positive
      return searchProducts(x);
    }

    else{
      if (minPrice < 0){//from highest to zero dollars/negative values are zero
        minPrice = 0;
      }
      for (Product p : list) {
        if (p.getPrice() >= minPrice && p.getPrice()<= maxPrice){
          newlist.add(p);
        }
      }

      return newlist;
    }
  }
  public boolean addStock(Product p, int amount){
    for (Product prod : stock) {
      if (prod.equals(p)){
        prod.setStockQuantity(prod.getStockQuantity() + amount);
        return true;
      }
    }

    return false;
  }
  public boolean sellProduct(Product p, Customer c, int amount){// part 8
    if (!stock.contains(p) || !cust.contains(c) || p.getStockQuantity() < amount){
      return false;
    }
    else if (c.getHistory().containsKey(p)) {//if keyset contains p
      p.sellUnits(amount);
      return c.addHistory(p, c.getHistory().get(p) + amount);//changes key value to new value

    }
    p.sellUnits(amount);
    return c.addHistory(p,amount);//adds new spot in history

  }
  public boolean addProduct(Product newProduct){
    for (Product p : stock) {
      if (p.toString().equals(newProduct.toString())){//if object toStrings are equal, that means they are same object (given the specs)
        return false;
      }
    }

    stock.add(newProduct);
    return true;
  }
  public HashMap<Customer, Integer> createMap(){ //makes hashmap of what was spent on
    HashMap<Customer, Integer> spentList = new HashMap<>();

    for (Customer c: cust){
      int i = 0;
      for (Product p : c.getHistory().keySet()){
        i += p.getPrice() * c.getHistory().get(p);
      }
      spentList.put(c,i);
    }

    return spentList;
  }
  public List<Customer> getTopXCustomers(int x){//compareTo function
    List<Customer> list = new ArrayList<>();
    HashMap<Customer, Integer> spentList = createMap();
    int count = 0;
    int i;
    Customer holder = null;

    if (x <= 0){
      return list;
    }
    else if (x >= cust.size()) {//if x > cust.size(), set to cust.size() (will be entire list)
      x = cust.size();
    }

    while (count < x){
      i = 0;
      for (Customer c : spentList.keySet()) {
        if (spentList.get(c) >= i && !list.contains(c)){ //since im not comparing with objects, not using compareTo method
          i = spentList.get(c);
          holder = c;

        }

      }
      list.add(holder);
      count++;
    }
    //System.out.println(spentList.keySet()); used to see key and values
    //System.out.println(spentList.values());

    return list;
  }
  public boolean saveToFile(String filename) {//formatting of file matters so i can readfromfile

    try {
      ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename));
      for (Customer c: cust){
        if (c != null){
          out.writeObject(c);
        }
      }

      for (Product p: stock){
        if (p != null){
          out.writeObject(p);
        }
      }

      out.close();
      return true;

    } catch (FileNotFoundException e) {
      // Do Nothing
    } catch (IOException e) {
      // Do Nothing
    }
    return false;
  }
  public static ElectronicStore loadFromFile(String filename){
    try {
      ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename));
      ElectronicStore store;

      store = ElectronicStore.readFrom(in);

      in.close();
      return store;

    } catch (FileNotFoundException e) {
      // Do Nothing
    } catch (IOException e) {
      // Do Nothing
    }


    return null;
  }
  public static ElectronicStore readFrom(ObjectInputStream aFile) throws IOException {
    Object o;
    Customer c;
    Product p;
    ElectronicStore s = new ElectronicStore("name");

    while (true) {//keep looping until eof
      try {
        o = aFile.readObject();

        if (o instanceof Customer){
          c = (Customer) o;
          s.registerCustomer(c);
        }
        else if (o instanceof Product) {
          p = (Product) o;
          s.addProduct(p);
        }

      } catch (ClassNotFoundException e) {
        // Do Nothing
      } catch (EOFException e){//get out of method when error happens
        break;
      }

    }
    return s;
  }

} 