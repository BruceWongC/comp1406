import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.collections.FXCollections;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class ElectronicStoreAppView extends Pane{
    private final ListView<String>    popularList;
    private final ListView<String> stockList;
    private final ListView<String> cartList;
    private final Button resetButton;
    private final Button addButton;
    private final Button removeButton;
    private final Button saleButton;
    private final TextField sField;
    private final TextField rField;
    private final TextField fField;
    private final LinkedHashMap<String, Integer> curCartList;
    private final LinkedHashMap<String, Integer> quantityList;
    private final Label labelCart;
    private boolean flag;
    private float displayRev;
    private int sales;
    public ElectronicStoreAppView(){
        curCartList = new LinkedHashMap<>(); //the holds data of current list
        quantityList = new LinkedHashMap<>(); //how much is currently in each product
        flag = true;
        displayRev = 0f;
        sales = 0;

        Label label1 = new Label("Store Summary:");
        label1.relocate(50, 10);

        Label label2 = new Label("# Sales:");
        label2.relocate(40, 40);

        Label label3 = new Label("Revenue:");
        label3.relocate(30, 70);

        Label label4 = new Label("$ / Sale:");
        label4.relocate(37, 100);

        Label label5 = new Label("Store Stock:");
        label5.relocate(310, 10);

        Label label6 = new Label("Most Popular Items:");
        label6.relocate(50, 130);

        labelCart = new Label(String.format("Current Cart($%.2f):",displayRev));
        labelCart.relocate(610, 10);

        sField = new TextField("0");
        sField.relocate(85, 40);
        sField.setPrefSize(100,10);
        sField.setEditable(false);

        rField = new TextField("0.00");
        rField.relocate(85, 70);
        rField.setPrefSize(100,10);
        rField.setEditable(false);

        fField = new TextField("N/A");
        fField.relocate(85, 100);
        fField.setPrefSize(100,10);
        fField.setEditable(false);

        popularList = new ListView<>();
        popularList.relocate(10, 150);
        popularList.setPrefSize(180,180);

        stockList = new ListView<>();
        stockList.relocate(200, 30);
        stockList.setPrefSize(290,300);

        cartList = new ListView<>();
        cartList.relocate(500, 30);
        cartList.setPrefSize(290,300);

        resetButton = new Button("Reset Store");
        resetButton.relocate(25, 335);
        resetButton.setPrefSize(145,50);

        addButton = new Button("Add to Cart");
        addButton.relocate(280, 335);
        addButton.setPrefSize(145,50);
        addButton.setDisable(true);

        removeButton = new Button("Remove from Cart");
        removeButton.relocate(500, 335);
        removeButton.setPrefSize(145,50);
        removeButton.setDisable(true);

        saleButton = new Button("Complete Sale");
        saleButton.relocate(645, 335);
        saleButton.setPrefSize(145,50);
        saleButton.setDisable(true);

        getChildren().addAll(label1,label2,label3,label4,label5,label6,labelCart,sField,rField,fField,popularList,stockList,cartList,resetButton,addButton,removeButton,saleButton);
    }
    public ListView<String> getStockList() {
        return stockList;
    }
    public ListView<String> getCartList() {
        return cartList;
    }
    public Button getAddButton(){
        return addButton;
    }
    public Button getSaleButton(){
        return saleButton;
    }
    public Button getRemoveButton(){
        return removeButton;
    }
    public Button getResetButton(){
        return resetButton;
    }
    public void update(ElectronicStore model){
        List<String> stock = new ArrayList<>();
        List<String> popular = new ArrayList<>();
        int count = 0;
        Product curHigh = null;
        int i;

        if(flag){ //fill in curCartList with the base data once
            for (Product p : model.getStock()) {
                if (p != null) {
                    curCartList.put(p.toString(), 0);
                }
            }
        }
        flag = false;

        for (Product p : model.getStock()) {//add to stock list unless all stock is in curCartList
            if (p != null && curCartList.get(p.toString()) != p.getStockQuantity()){
                stock.add(p.toString());
            }
            if (p != null) {//the quantity of each item
                quantityList.put(p.toString(),p.getStockQuantity());

            }
        }


        while (count < 3){//popularlist implementation
            i = -1;
            for (Product p : model.getStock()) {
                if (p != null){
                    if (p.getSoldQuantity() > i && !popular.contains(p.toString())){
                        i = p.getSoldQuantity();
                        curHigh = p;
                    }
                }
            }

            if (curHigh != null){
                popular.add(curHigh.toString());
                count++;
            }
        }

        stockList.setItems(FXCollections.observableList(stock));
        popularList.setItems(FXCollections.observableList(popular));

    }

    public void update(ElectronicStore model, String stockString){//split this to another method for clarity
        addButton.setDisable(stockString == null);//only enables button if string isn't null (anything but the contents)
        update(model);

    }

    public void updateCartList(ElectronicStore model, String cartString){
        List<String> cart = new ArrayList<>();
        if (curCartList.containsKey(cartString)) {//if set has key, add 1 to that key
            curCartList.put(cartString, curCartList.get(cartString) + 1);

        }
        for (String s : curCartList.keySet()) {//makes list of how many of each item is in curCartList
            if (curCartList.get(s) != 0) {
                cart.add(curCartList.get(s) + " x " + s);
            }
        }

        displayRev += model.getStockItem(cartString).getPrice(); //use for changing the label
        String displayStr = String.format("Current Cart($%.2f):",displayRev);
        labelCart.setText(displayStr);

        saleButton.setDisable(cart.isEmpty());
        cartList.setItems(FXCollections.observableList(cart));

        if (curCartList.get(cartString).equals(quantityList.get(cartString))){//when all items are in cart, disable addButton
            update(model,null);
        }
        else{
            update(model);//or else update
        }

    }
    public void updateOpenRemove(ElectronicStore model, String removeString){
        removeButton.setDisable(removeString == null);//enable button if item is selected
        update(model);

    }
    public void updateRemove(ElectronicStore model, String cartString){
        List<String> cart = new ArrayList<>();

        for (String s : curCartList.keySet()) {
            if (cartString.contains(s)){//removes an item in curCartList if string contains key
                curCartList.put(s, curCartList.get(s) - 1);
                displayRev -= model.getStockItem(s).getPrice();
            }
        }

        for (String s : curCartList.keySet()) {
            if (curCartList.get(s) != 0){
                cart.add(curCartList.get(s) + " x " + s);//updates the list
            }
        }

        String displayStr = String.format("Current Cart($%.2f):",displayRev);
        labelCart.setText(displayStr);

        saleButton.setDisable(cart.isEmpty());//cart needs to have an item before sale button can be enabled
        removeButton.setDisable(true);//item removed, disable button
        cartList.setItems(FXCollections.observableList(cart));
        update(model);

    }
    public void updateSale(ElectronicStore model){
        for (String s : curCartList.keySet()) {
            model.getStockItem(s).sellUnits(curCartList.get(s));
            model.setRevenue(model.getRevenue() + model.getStockItem(s).getPrice() * curCartList.get(s));
            sales += curCartList.get(s);
            curCartList.put(s,0);//what's in cart is now empty
        }
        displayRev = 0;

        double ratio = model.getRevenue() / sales;

        //change textbox numbers
        String str1 = String.format("%.2f", model.getRevenue());
        String str2 = Integer.toString(sales);
        String str3 = String.format("%.2f", ratio);

        rField.setText(str1);
        sField.setText(str2);
        fField.setText(str3);

        String displayStr = String.format("Current Cart($%.2f):",displayRev);
        labelCart.setText(displayStr);

        cartList.getItems().clear();//carList has no items
        saleButton.setDisable(true);
        update(model);
    }
    public void reset(ElectronicStore model){//resets all instance variables to initial values
        flag = true;
        displayRev = 0f;
        sales = 0;
        model.setRevenue(0);

        curCartList.clear();
        quantityList.clear();

        labelCart.setText(String.format("Current Cart($%.2f):",displayRev));

        rField.setText("0");
        sField.setText(String.format("%.2f",model.getRevenue()));
        fField.setText("N/A");

        stockList.getItems().clear();
        cartList.getItems().clear();

        update(model);

    }

}
