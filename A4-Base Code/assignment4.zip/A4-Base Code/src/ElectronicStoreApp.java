import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class ElectronicStoreApp extends Application {
    private ElectronicStore model;
    public ElectronicStoreApp() {
        model = ElectronicStore.createStore();
    }

    public void start(Stage primaryStage) {
        Pane aPane = new Pane();

        ElectronicStoreAppView view = new ElectronicStoreAppView();

        aPane.getChildren().add(view);
        view.update(model);

        view.getStockList().setOnMouseClicked(new EventHandler<MouseEvent>() //setOnMousePressed
        {
            public void handle(MouseEvent mouseEvent) {

                String selected = view.getStockList().getSelectionModel().getSelectedItem();

                view.update(model, selected);

            }
        });

        view.getCartList().setOnMouseClicked(new EventHandler<MouseEvent>() //setOnMousePressed
        {
            public void handle(MouseEvent mouseEvent) {

                String selected = view.getCartList().getSelectionModel().getSelectedItem();

                view.updateOpenRemove(model,selected);

            }
        });

        view.getAddButton().setOnMouseClicked(new EventHandler<MouseEvent>() //setOnMousePressed
        {
            public void handle(MouseEvent mouseEvent) {

                String selected = view.getStockList().getSelectionModel().getSelectedItem(); //in update, lower stock, up soldquant and record sales

                view.updateCartList(model,selected);
            }
        });

        view.getSaleButton().setOnMouseClicked(new EventHandler<MouseEvent>() //setOnMousePressed
        {
            public void handle(MouseEvent mouseEvent) {

                view.updateSale(model);

            }
        });

        view.getRemoveButton().setOnMouseClicked(new EventHandler<MouseEvent>() //setOnMousePressed
        {
            public void handle(MouseEvent mouseEvent) {

                String selected = view.getCartList().getSelectionModel().getSelectedItem(); //in update, lower stock, up soldquant and record sales

                view.updateRemove(model, selected);

            }
        });

        view.getResetButton().setOnMouseClicked(new EventHandler<MouseEvent>()
        {
            public void handle(MouseEvent mouseEvent) {
                model = ElectronicStore.createStore();//resets model
                view.reset(model);

            }
        });

        primaryStage.setTitle("Electronic Store Application");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(aPane,800, 400));
        primaryStage.show();


    }

    public static void main(String[] args) {
        launch(args);
    }



}