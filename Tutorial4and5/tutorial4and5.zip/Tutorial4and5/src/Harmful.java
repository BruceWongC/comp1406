public interface Harmful {
    public int getDamageAmount();
}